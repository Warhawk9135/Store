function loadData(name){
	if(name == "button1"){
	document.getElementById("pic1").src="../Images/apple.jpg";
	document.getElementById("para").innerHTML="The iPhone XS and iPhone XS Max, introdrced on September 12, 2018, Apple's two new flagship iPhones, featuring the most advanced technology Apple has ever introduced in an iPhone. Both of the new iPhones look similar to the iPhone X, but in addition to the 5.8-inch model, there's also now a larger 6.5-inch model. iPhone XS and iPhone XS Max feature the sharpest OLED displays and highest pixel density of any Apple device, with support for Dolby Vision, HDR 10, and Wide Color. iPhone XS Max, the 6.5-inch iPhone, is the largest display Apple has offered, but in a body that's the size of the iPhone 8 Plus. According to Apple, the iPhone XS and XS Max have the most durable glass ever in a smartphone with better scratch resistance.";
  
  }else if(name =="button2") {
  	document.getElementById("pic1").src="../Images/x1.jpg";
	document.getElementById("para").innerHTML="On September 12, 2018, Apple announced iPhone XS, iPhone XS Max, and iPhone XR. iPhone XS and iPhone XS Max features Super Retina display, a high-speed, improved dual camera system with innovative photo and video functions, a new generation of smartphone's first 7 nm chips Neuro Engine's A12 bionic chip - Faster face ID, wider stereo sound, and dual card for iPhone. The iPhone XR is a state-of-the-art smart phone LCD display, a 6.1-inch liquid retina display, an A12 biomimetic chip with a next-generation neuro engine, a TrueDepth camera system, full-screen glass and advanced aluminum design with face recognition and advanced features A camera lens system for creating a portrait portrait with a single camera lens"

  }else if (name =="button3"){
  	document.getElementById("pic1").src="../Images/xx.png";
	document.getElementById("para").innerHTML="The iPhone XS Max (pronounced 'Ten S Max') was the largest smartphone Apple had ever released when it launched in September 2018. With a 6.5-inch display, hardly any screen bezel, and the now-iconic top-screen notch, it was a dominating presence in the hand.Sure, it's no longer Apple's latest 'Max' product, with the iPhone 11 Pro Max taking that slot (and the iPhone 11 and iPhone 11 Pro stealing the title of latest flagship iPhones) but it's still an impressive piece of kit. It's fast, has great cameras, and longer-lasting battery than most of Apple's lineup.The new set of Apple smartphones led the tech giant to drop the iPhone XS Max from its stores to simplify the product range, but it's still available from retailers and carriers – and at a lower cost than when it launched.While the iPhone XS Max was the largest and most expensive iPhone at launch with its 6.5-inch display, it's been surpassed in both size and cost by premium Android flagships. The phone still dominates your pocket, which was a bold statement from a firm that had resisted expanding its phones' screen sizes to the same enormous degree as its Android rivals.For those who crave more screen for video and gaming on the go, the expansive display of the iPhone XS Max (and newer iPhone 11 Pro Max) will be a welcome addition to Apple’s lineup, while those wanting a premium experience without the supersized dimensions can take comfort that it’s launched alongside the smaller iPhone XS"
  }else if (name=="button4"){
  	document.getElementById("pic1").src="../Images/8p.jpg";
  	document.getElementById("para").innerHTML="iPhone 8 and iPhone 8 Plus introduce a beautiful glass back design made with the most durable glass ever in a smartphone in three new finishes: space gray, silver and gold. The glass finish is made using a seven-layer color process for precise hue and opacity, delivering a rich depth of color with a color-matched aerospace-grade aluminum bezel, and is water and dust resistantThe new 4.7-inch and 5.5-inch Retina HD displays with the addition of True Tone adjust the white balance of the display to match the surrounding light for a more natural, paper-like viewing experience. The vibrant wide color gamut Retina HD display offers the best color accuracy in the industry. Redesigned stereo speakers are up to 25 percent louder and deliver deeper bass, enabling richer-sounding music, videos and speakerphone calls.A11 Bionic, the most powerful and smartest chip ever in a smartphone, features a six-core CPU design with two performance cores that are 25 percent faster and four efficiency cores that are 70 percent faster than the A10 Fusion, offering industry-leading performance and energy efficiency. A new, second-generation performance controller can harness all six cores simultaneously, delivering up to 70 percent greater performance for multi-threaded workloads, giving customers more power while providing the same great battery life. A11 Bionic also integrates an Apple-designed GPU with a three-core design that delivers up to 30 percent faster graphics performance than the previous generation. All this power enables incredible new machine learning, AR apps and immersive 3D games."

  }else if(name=="button5"){
  	document.getElementById("pic1").src="../Images/se.jpg";
  	document.getElementById("para").innerHTML="This iPhone SE is larger than the original iPhone SE: It has a 4.7-inch diagonal display, instead of a tiny 4-inch one. And yet, the 4.7-inch display still felt too small to me.The advantages of a small phone are obvious. It’s easier to use with one hand. It’s more pocketable, which is great for running errands and can’t be overlooked if your main source of activity these days is walking or running outside. A smaller phone makes you feel as though you have control over your phone, not the other way around. But it’s also less immersive for watching videos, playing games, and reading. I read this entire WIRED essay on the iPhone SE early one morning, and it occurred to me halfway through that it wasn’t really a pleasant experience. I’d rather get lost in a phone screen closer to six inches in size.A smalle phone body also means a smaller battery. This iPhone S has essentially the same size battery as the iPhone 8; thanks to a much more efficient processor, the SE’s battery should perform better than the iPhone 8’s. And yet, relative to larger iPhones—the “Pro” or “Max” models, the iPhone XR, my iPhone 11—the iPhone SE’s battery life is middling.My battery drain wasn’t as pronounced as it might have been before we were all sheltering in place. For example, I’m not using the iPhone SE’s GPS, or calling Lyfts, or streaming podcasts and videos during my commute. (Nor am I commuting.) On days when I used it for phone calls, scrolling Twitter and Instagram, checking email, and responding to messages, it just about made it to the end of the day before it hit the low battery mark. Streaming an hour-long yoga video on YouTube, which would reduce battery life by about 15 percent, meant I’d likely have to plug the phone in again before the day’s end. Streaming the same video on iPhone 11 drained the battery 5 percent."
  }else{
  	alert("invalid");
  }
}

function priceloop() {
	
	 document.getElementById("pic1").src="../Images/pic.jpg"



	var phones =["I PHONE 11PRO=$3000","I PHONE XS MAX =$2000","I PHONE XS=$1600","I PHONE 8PLUS=1400","I PHONE SE (2020)=$600","I PHONE 8=$1000","I PHONE 7 PLUS=$700"];

	var i;
	var txt="";
    var length= phones.length;

	for(i=0;i<length; i++){
		txt+= phones[i] + "<br/>";

        document.getElementById("para").innerHTML=txt;
	}

	
}
function kpriceloop() {
	 document.getElementById("pic1").src="../Images/high.jpg"
	
 var phones=[];
 var txt ="";

 phones["I PHONE 11PRO"] = 3000;
 phones["I PHONE XS MAX"] =2000;
 phones["I PHONE XS"]=1600;
 phones["I PHONE 8PLUS "]=1400;
 phones["I PHONE SE (2020)"]=600;
 phones["I PHONE 8"]=1000;
 phones["I PHONE 7 PLUS"]=700;

 for(var item in phones ){
 	if(phones[item]>1500){
 		txt += item + " :  " + phones[item] + "<br/>";
 	}
 }
 document.getElementById("para").innerHTML=txt;

}

function lowpriceloop() {
	 document.getElementById("pic1").src="../Images/low.jpg"
	
 var phones=[];
 var txt ="";

 phones["I PHONE 11PRO"] = 3000;
 phones["I PHONE XS MAX"] =2000;
 phones["I PHONE XS"]=1600;
 phones["I PHONE 8PLUS "]=1400;
 phones["I PHONE SE (2020)"]=600;
 phones["I PHONE 8"]=1000;
 phones["I PHONE 7 PLUS"]=700;

 for(var item in phones ){
 	if(phones[item]<1500){
 		txt += item + " :  " + phones[item] + "<br/>";
 	}
 }
 document.getElementById("para").innerHTML=txt;

}
